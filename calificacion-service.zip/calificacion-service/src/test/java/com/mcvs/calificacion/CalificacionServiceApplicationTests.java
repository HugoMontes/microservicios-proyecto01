package com.mcvs.calificacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalificacionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
